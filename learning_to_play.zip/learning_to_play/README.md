# Learning to play with intrinsically-motivated self-aware agents.

Currently just the model generation, data providing, and training utils. Environment binary and messaging pipeline to be added.

Requires https://github.com/neuroailab/tfutils/tree/interaction_utils/.
